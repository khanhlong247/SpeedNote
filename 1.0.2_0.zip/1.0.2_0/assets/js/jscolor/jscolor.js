/**
 * jscolor, JavaScript Color Picker
 *
 * @version 1.4.5
 * @license GNU Lesser General Public License, http://www.gnu.org/copyleft/lesser.html
 * @author  Jan Odvarko, http://odvarko.cz
 * @created 2008-06-15
 * @updated 2015-09-19
 * @link    http://jscolor.com
 */
var jscolor = {
  dir: "",
  bindClass: "color",
  binding: !0,
  preloading: !0,
  install: function () {
    jscolor.addEvent(window, "load", jscolor.init);
  },
  init: function () {
    jscolor.binding && jscolor.bind(), jscolor.preloading && jscolor.preload();
  },
  getDir: function () {
    if (!jscolor.dir) {
      var e = jscolor.detectDir();
      jscolor.dir = !1 !== e ? e : "jscolor/";
    }
    return jscolor.dir;
  },
  detectDir: function () {
    for (
      var e = location.href, t = document.getElementsByTagName("base"), o = 0;
      o < t.length;
      o += 1
    )
      t[o].href && (e = t[o].href);
    for (
      t = document.getElementsByTagName("script"), o = 0;
      o < t.length;
      o += 1
    )
      if (t[o].src && /(^|\/)jscolor\.js([?#].*)?$/i.test(t[o].src)) {
        var r = new jscolor.URI(t[o].src).toAbsolute(e);
        return (
          (r.path = r.path.replace(/[^\/]+$/, "")),
          (r.query = null),
          (r.fragment = null),
          r.toString()
        );
      }
    return !1;
  },
  bind: function () {
    for (
      var e = new RegExp(
          "(^|\\s)(" + jscolor.bindClass + ")(\\s*(\\{[^}]*\\})|\\s|$)",
          "i"
        ),
        t = document.getElementsByTagName("input"),
        o = 0;
      o < t.length;
      o += 1
    ) {
      var r;
      if (!jscolor.isColorAttrSupported || "color" != t[o].type.toLowerCase())
        if (!t[o].color && t[o].className && (r = t[o].className.match(e))) {
          var s = {};
          if (r[4])
            try {
              s = new Function("return (" + r[4] + ")")();
            } catch (e) {}
          t[o].color = new jscolor.color(t[o], s);
        }
    }
  },
  preload: function () {
    for (var e in jscolor.imgRequire)
      jscolor.imgRequire.hasOwnProperty(e) && jscolor.loadImage(e);
  },
  images: { pad: [181, 101], sld: [16, 101], cross: [15, 15], arrow: [7, 11] },
  imgRequire: {},
  imgLoaded: {},
  requireImage: function (e) {
    jscolor.imgRequire[e] = !0;
  },
  loadImage: function (e) {
    jscolor.imgLoaded[e] ||
      ((jscolor.imgLoaded[e] = new Image()),
      (jscolor.imgLoaded[e].src = jscolor.getDir() + e));
  },
  fetchElement: function (e) {
    return "string" == typeof e ? document.getElementById(e) : e;
  },
  addEvent: function (e, t, o) {
    e.addEventListener
      ? e.addEventListener(t, o, !1)
      : e.attachEvent && e.attachEvent("on" + t, o);
  },
  fireEvent: function (e, t) {
    if (e)
      if (document.createEvent)
        (o = document.createEvent("HTMLEvents")).initEvent(t, !0, !0),
          e.dispatchEvent(o);
      else if (document.createEventObject) {
        var o = document.createEventObject();
        e.fireEvent("on" + t, o);
      } else e["on" + t] && e["on" + t]();
  },
  getElementPos: function (e) {
    var t = e,
      o = e,
      r = 0,
      s = 0;
    if (t.offsetParent)
      do {
        (r += t.offsetLeft), (s += t.offsetTop);
      } while ((t = t.offsetParent));
    for (; (o = o.parentNode) && "BODY" !== o.nodeName.toUpperCase(); )
      (r -= o.scrollLeft), (s -= o.scrollTop);
    return [r, s];
  },
  getElementSize: function (e) {
    return [e.offsetWidth, e.offsetHeight];
  },
  getRelMousePos: function (e) {
    var t = 0,
      o = 0;
    return (
      e || (e = window.event),
      "number" == typeof e.offsetX
        ? ((t = e.offsetX), (o = e.offsetY))
        : "number" == typeof e.layerX && ((t = e.layerX), (o = e.layerY)),
      { x: t, y: o }
    );
  },
  getViewPos: function () {
    return "number" == typeof window.pageYOffset
      ? [window.pageXOffset, window.pageYOffset]
      : document.body && (document.body.scrollLeft || document.body.scrollTop)
      ? [document.body.scrollLeft, document.body.scrollTop]
      : document.documentElement &&
        (document.documentElement.scrollLeft ||
          document.documentElement.scrollTop)
      ? [
          document.documentElement.scrollLeft,
          document.documentElement.scrollTop,
        ]
      : [0, 0];
  },
  getViewSize: function () {
    return "number" == typeof window.innerWidth
      ? [window.innerWidth, window.innerHeight]
      : document.body &&
        (document.body.clientWidth || document.body.clientHeight)
      ? [document.body.clientWidth, document.body.clientHeight]
      : document.documentElement &&
        (document.documentElement.clientWidth ||
          document.documentElement.clientHeight)
      ? [
          document.documentElement.clientWidth,
          document.documentElement.clientHeight,
        ]
      : [0, 0];
  },
  URI: function (e) {
    function t(e) {
      for (var t = ""; e; )
        if ("../" === e.substr(0, 3) || "./" === e.substr(0, 2))
          e = e.replace(/^\.+/, "").substr(1);
        else if ("/./" === e.substr(0, 3) || "/." === e) e = "/" + e.substr(3);
        else if ("/../" === e.substr(0, 4) || "/.." === e)
          (e = "/" + e.substr(4)), (t = t.replace(/\/?[^\/]*$/, ""));
        else if ("." === e || ".." === e) e = "";
        else {
          var o = e.match(/^\/?[^\/]*/)[0];
          (e = e.substr(o.length)), (t += o);
        }
      return t;
    }
    (this.scheme = null),
      (this.authority = null),
      (this.path = ""),
      (this.query = null),
      (this.fragment = null),
      (this.parse = function (e) {
        var t = e.match(
          /^(([A-Za-z][0-9A-Za-z+.-]*)(:))?((\/\/)([^\/?#]*))?([^?#]*)((\?)([^#]*))?((#)(.*))?/
        );
        return (
          (this.scheme = t[3] ? t[2] : null),
          (this.authority = t[5] ? t[6] : null),
          (this.path = t[7]),
          (this.query = t[9] ? t[10] : null),
          (this.fragment = t[12] ? t[13] : null),
          this
        );
      }),
      (this.toString = function () {
        var e = "";
        return (
          null !== this.scheme && (e = e + this.scheme + ":"),
          null !== this.authority && (e = e + "//" + this.authority),
          null !== this.path && (e += this.path),
          null !== this.query && (e = e + "?" + this.query),
          null !== this.fragment && (e = e + "#" + this.fragment),
          e
        );
      }),
      (this.toAbsolute = function (e) {
        e = new jscolor.URI(e);
        var o = this,
          r = new jscolor.URI();
        return (
          null !== e.scheme &&
          (null !== o.scheme &&
            o.scheme.toLowerCase() === e.scheme.toLowerCase() &&
            (o.scheme = null),
          null !== o.scheme
            ? ((r.scheme = o.scheme),
              (r.authority = o.authority),
              (r.path = t(o.path)),
              (r.query = o.query))
            : (null !== o.authority
                ? ((r.authority = o.authority),
                  (r.path = t(o.path)),
                  (r.query = o.query))
                : ("" === o.path
                    ? ((r.path = e.path),
                      null !== o.query
                        ? (r.query = o.query)
                        : (r.query = e.query))
                    : ("/" === o.path.substr(0, 1)
                        ? (r.path = t(o.path))
                        : (null !== e.authority && "" === e.path
                            ? (r.path = "/" + o.path)
                            : (r.path = e.path.replace(/[^\/]+$/, "") + o.path),
                          (r.path = t(r.path))),
                      (r.query = o.query)),
                  (r.authority = e.authority)),
              (r.scheme = e.scheme)),
          (r.fragment = o.fragment),
          r)
        );
      }),
      e && this.parse(e);
  },
  color: function (e, t) {
    for (var o in ((this.required = !0),
    (this.adjust = !0),
    (this.hash = !1),
    (this.caps = !0),
    (this.slider = !0),
    (this.valueElement = e),
    (this.styleElement = e),
    (this.onImmediateChange = null),
    (this.hsv = [0, 0, 1]),
    (this.rgb = [1, 1, 1]),
    (this.minH = 0),
    (this.maxH = 6),
    (this.minS = 0),
    (this.maxS = 1),
    (this.minV = 0),
    (this.maxV = 1),
    (this.pickerOnfocus = !0),
    (this.pickerMode = "HSV"),
    (this.pickerPosition = "bottom"),
    (this.pickerSmartPosition = !0),
    (this.pickerFixedPosition = !1),
    (this.pickerButtonHeight = 20),
    (this.pickerClosable = !1),
    (this.pickerCloseText = "Close"),
    (this.pickerButtonColor = "ButtonText"),
    (this.pickerFace = 10),
    (this.pickerFaceColor = "ThreeDFace"),
    (this.pickerBorder = 1),
    (this.pickerBorderColor =
      "ThreeDHighlight ThreeDShadow ThreeDShadow ThreeDHighlight"),
    (this.pickerInset = 1),
    (this.pickerInsetColor =
      "ThreeDShadow ThreeDHighlight ThreeDHighlight ThreeDShadow"),
    (this.pickerZIndex = 1e4),
    t))
      t.hasOwnProperty(o) && (this[o] = t[o]);
    function r(e, t, o) {
      if (null === e) return [o, o, o];
      var r = Math.floor(e),
        s = o * (1 - t),
        i = o * (1 - t * (r % 2 ? e - r : 1 - (e - r)));
      switch (r) {
        case 6:
        case 0:
          return [o, i, s];
        case 1:
          return [i, o, s];
        case 2:
          return [s, o, i];
        case 3:
          return [s, i, o];
        case 4:
          return [i, s, o];
        case 5:
          return [o, s, i];
      }
    }
    function s(e) {
      return [
        2 * e.pickerInset +
          2 * e.pickerFace +
          jscolor.images.pad[0] +
          (e.slider
            ? 2 * e.pickerInset +
              2 * jscolor.images.arrow[0] +
              jscolor.images.sld[0]
            : 0),
        e.pickerClosable
          ? 4 * e.pickerInset +
            3 * e.pickerFace +
            jscolor.images.pad[1] +
            e.pickerButtonHeight
          : 2 * e.pickerInset + 2 * e.pickerFace + jscolor.images.pad[1],
      ];
    }
    function i() {
      switch (d) {
        case 0:
          var e = 1;
          break;
        case 1:
          e = 2;
      }
      var t = Math.round((u.hsv[0] / 6) * (jscolor.images.pad[0] - 1)),
        o = Math.round((1 - u.hsv[e]) * (jscolor.images.pad[1] - 1));
      jscolor.picker.padM.style.backgroundPosition =
        u.pickerFace +
        u.pickerInset +
        t -
        Math.floor(jscolor.images.cross[0] / 2) +
        "px " +
        (u.pickerFace +
          u.pickerInset +
          o -
          Math.floor(jscolor.images.cross[1] / 2)) +
        "px";
      var s = jscolor.picker.sld.childNodes;
      switch (d) {
        case 0:
          for (var i = r(u.hsv[0], u.hsv[1], 1), n = 0; n < s.length; n += 1)
            s[n].style.backgroundColor =
              "rgb(" +
              i[0] * (1 - n / s.length) * 100 +
              "%," +
              i[1] * (1 - n / s.length) * 100 +
              "%," +
              i[2] * (1 - n / s.length) * 100 +
              "%)";
          break;
        case 1:
          var l,
            c = [u.hsv[2], 0, 0],
            a =
              (n = Math.floor(u.hsv[0])) % 2
                ? u.hsv[0] - n
                : 1 - (u.hsv[0] - n);
          switch (n) {
            case 6:
            case 0:
              i = [0, 1, 2];
              break;
            case 1:
              i = [1, 0, 2];
              break;
            case 2:
              i = [2, 0, 1];
              break;
            case 3:
              i = [2, 1, 0];
              break;
            case 4:
              i = [1, 2, 0];
              break;
            case 5:
              i = [0, 2, 1];
          }
          for (n = 0; n < s.length; n += 1)
            (l = 1 - (1 / (s.length - 1)) * n),
              (c[1] = c[0] * (1 - l * a)),
              (c[2] = c[0] * (1 - l)),
              (s[n].style.backgroundColor =
                "rgb(" +
                100 * c[i[0]] +
                "%," +
                100 * c[i[1]] +
                "%," +
                100 * c[i[2]] +
                "%)");
      }
    }
    function n() {
      switch (d) {
        case 0:
          var e = 2;
          break;
        case 1:
          e = 1;
      }
      var t = Math.round((1 - u.hsv[e]) * (jscolor.images.sld[1] - 1));
      jscolor.picker.sldM.style.backgroundPosition =
        "0 " +
        (u.pickerFace +
          u.pickerInset +
          t -
          Math.floor(jscolor.images.arrow[1] / 2)) +
        "px";
    }
    function l() {
      return jscolor.picker && jscolor.picker.owner === u;
    }
    function c(e) {
      var t = jscolor.getRelMousePos(e),
        o = t.x - u.pickerFace - u.pickerInset,
        r = t.y - u.pickerFace - u.pickerInset;
      switch (d) {
        case 0:
          u.fromHSV(
            o * (6 / (jscolor.images.pad[0] - 1)),
            1 - r / (jscolor.images.pad[1] - 1),
            null,
            x
          );
          break;
        case 1:
          u.fromHSV(
            o * (6 / (jscolor.images.pad[0] - 1)),
            null,
            1 - r / (jscolor.images.pad[1] - 1),
            x
          );
      }
    }
    function a(e) {
      var t = jscolor.getRelMousePos(e).y - u.pickerFace - u.pickerInset;
      switch (d) {
        case 0:
          u.fromHSV(null, null, 1 - t / (jscolor.images.sld[1] - 1), j);
          break;
        case 1:
          u.fromHSV(null, 1 - t / (jscolor.images.sld[1] - 1), null, j);
      }
    }
    function h() {
      u.onImmediateChange &&
        ("string" == typeof u.onImmediateChange
          ? new Function(u.onImmediateChange)
          : u.onImmediateChange
        ).call(u);
    }
    (this.hidePicker = function () {
      l() &&
        (delete jscolor.picker.owner,
        document
          .getElementsByTagName("body")[0]
          .removeChild(jscolor.picker.boxB));
    }),
      (this.showPicker = function () {
        if (!l()) {
          var t,
            o,
            r,
            g = jscolor.getElementPos(e),
            k = jscolor.getElementSize(e),
            v = jscolor.getViewPos(),
            j = jscolor.getViewSize(),
            x = s(this);
          switch (this.pickerPosition.toLowerCase()) {
            case "left":
              (t = 1), (o = 0), (r = -1);
              break;
            case "right":
              (t = 1), (o = 0), (r = 1);
              break;
            case "top":
              (t = 0), (o = 1), (r = -1);
              break;
            default:
              (t = 0), (o = 1), (r = 1);
          }
          var w = (k[o] + x[o]) / 2;
          if (this.pickerSmartPosition)
            C = [
              -v[t] + g[t] + x[t] > j[t] &&
              -v[t] + g[t] + k[t] / 2 > j[t] / 2 &&
              g[t] + k[t] - x[t] >= 0
                ? g[t] + k[t] - x[t]
                : g[t],
              -v[o] + g[o] + k[o] + x[o] - w + w * r > j[o]
                ? -v[o] + g[o] + k[o] / 2 > j[o] / 2 &&
                  g[o] + k[o] - w - w * r >= 0
                  ? g[o] + k[o] - w - w * r
                  : g[o] + k[o] - w + w * r
                : g[o] + k[o] - w + w * r >= 0
                ? g[o] + k[o] - w + w * r
                : g[o] + k[o] - w - w * r,
            ];
          else var C = [g[t], g[o] + k[o] - w + w * r];
          !(function (t, o) {
            if (!jscolor.picker) {
              jscolor.picker = {
                box: document.createElement("div"),
                boxB: document.createElement("div"),
                pad: document.createElement("div"),
                padB: document.createElement("div"),
                padM: document.createElement("div"),
                sld: document.createElement("div"),
                sldB: document.createElement("div"),
                sldM: document.createElement("div"),
                btn: document.createElement("div"),
                btnS: document.createElement("span"),
                btnT: document.createTextNode(u.pickerCloseText),
              };
              for (var r = 0, l = 4; r < jscolor.images.sld[1]; r += l) {
                var g = document.createElement("div");
                (g.style.height = l + "px"),
                  (g.style.fontSize = "1px"),
                  (g.style.lineHeight = "0"),
                  jscolor.picker.sld.appendChild(g);
              }
              jscolor.picker.sldB.appendChild(jscolor.picker.sld),
                jscolor.picker.box.appendChild(jscolor.picker.sldB),
                jscolor.picker.box.appendChild(jscolor.picker.sldM),
                jscolor.picker.padB.appendChild(jscolor.picker.pad),
                jscolor.picker.box.appendChild(jscolor.picker.padB),
                jscolor.picker.box.appendChild(jscolor.picker.padM),
                jscolor.picker.btnS.appendChild(jscolor.picker.btnT),
                jscolor.picker.btn.appendChild(jscolor.picker.btnS),
                jscolor.picker.box.appendChild(jscolor.picker.btn),
                jscolor.picker.boxB.appendChild(jscolor.picker.box);
            }
            var k = jscolor.picker;
            if (
              ((k.box.onmouseup = k.box.onmouseout =
                function () {
                  e.focus();
                }),
              (k.box.onmousedown = function () {
                p = !0;
              }),
              (k.box.onmousemove = function (e) {
                (f || b) &&
                  (f && c(e),
                  b && a(e),
                  document.selection
                    ? document.selection.empty()
                    : window.getSelection &&
                      window.getSelection().removeAllRanges(),
                  h());
              }),
              "ontouchstart" in window)
            ) {
              var v = function (e) {
                var t = {
                  offsetX: e.touches[0].pageX - y.X,
                  offsetY: e.touches[0].pageY - y.Y,
                };
                (f || b) && (f && c(t), b && a(t), h()),
                  e.stopPropagation(),
                  e.preventDefault();
              };
              k.box.removeEventListener("touchmove", v, !1),
                k.box.addEventListener("touchmove", v, !1);
            }
            (k.padM.onmouseup = k.padM.onmouseout =
              function () {
                f && ((f = !1), jscolor.fireEvent(m, "change"));
              }),
              (k.padM.onmousedown = function (e) {
                switch (d) {
                  case 0:
                    0 === u.hsv[2] && u.fromHSV(null, null, 1);
                    break;
                  case 1:
                    0 === u.hsv[1] && u.fromHSV(null, 1, null);
                }
                (b = !1), (f = !0), c(e), h();
              }),
              "ontouchstart" in window &&
                k.padM.addEventListener("touchstart", function (e) {
                  (y = {
                    X: e.target.offsetParent.offsetLeft,
                    Y: e.target.offsetParent.offsetTop,
                  }),
                    this.onmousedown({
                      offsetX: e.touches[0].pageX - y.X,
                      offsetY: e.touches[0].pageY - y.Y,
                    });
                });
            (k.sldM.onmouseup = k.sldM.onmouseout =
              function () {
                b && ((b = !1), jscolor.fireEvent(m, "change"));
              }),
              (k.sldM.onmousedown = function (e) {
                (f = !1), (b = !0), a(e), h();
              }),
              "ontouchstart" in window &&
                k.sldM.addEventListener("touchstart", function (e) {
                  (y = {
                    X: e.target.offsetParent.offsetLeft,
                    Y: e.target.offsetParent.offsetTop,
                  }),
                    this.onmousedown({
                      offsetX: e.touches[0].pageX - y.X,
                      offsetY: e.touches[0].pageY - y.Y,
                    });
                });
            var j = s(u);
            (k.box.style.width = j[0] + "px"),
              (k.box.style.height = j[1] + "px"),
              (k.boxB.style.position = u.pickerFixedPosition
                ? "fixed"
                : "absolute"),
              (k.boxB.style.clear = "both"),
              (k.boxB.style.left = t + "px"),
              (k.boxB.style.top = o + "px"),
              (k.boxB.style.zIndex = u.pickerZIndex),
              (k.boxB.style.border = u.pickerBorder + "px solid"),
              (k.boxB.style.borderColor = u.pickerBorderColor),
              (k.boxB.style.background = u.pickerFaceColor),
              (k.pad.style.width = jscolor.images.pad[0] + "px"),
              (k.pad.style.height = jscolor.images.pad[1] + "px"),
              (k.padB.style.position = "absolute"),
              (k.padB.style.left = u.pickerFace + "px"),
              (k.padB.style.top = u.pickerFace + "px"),
              (k.padB.style.border = u.pickerInset + "px solid"),
              (k.padB.style.borderColor = u.pickerInsetColor),
              (k.padM.style.position = "absolute"),
              (k.padM.style.left = "0"),
              (k.padM.style.top = "0"),
              (k.padM.style.width =
                u.pickerFace +
                2 * u.pickerInset +
                jscolor.images.pad[0] +
                jscolor.images.arrow[0] +
                "px"),
              (k.padM.style.height = k.box.style.height),
              (k.padM.style.cursor = "crosshair"),
              (k.sld.style.overflow = "hidden"),
              (k.sld.style.width = jscolor.images.sld[0] + "px"),
              (k.sld.style.height = jscolor.images.sld[1] + "px"),
              (k.sldB.style.display = u.slider ? "block" : "none"),
              (k.sldB.style.position = "absolute"),
              (k.sldB.style.right = u.pickerFace + "px"),
              (k.sldB.style.top = u.pickerFace + "px"),
              (k.sldB.style.border = u.pickerInset + "px solid"),
              (k.sldB.style.borderColor = u.pickerInsetColor),
              (k.sldM.style.display = u.slider ? "block" : "none"),
              (k.sldM.style.position = "absolute"),
              (k.sldM.style.right = "0"),
              (k.sldM.style.top = "0"),
              (k.sldM.style.width =
                jscolor.images.sld[0] +
                jscolor.images.arrow[0] +
                u.pickerFace +
                2 * u.pickerInset +
                "px"),
              (k.sldM.style.height = k.box.style.height);
            try {
              k.sldM.style.cursor = "pointer";
            } catch (e) {
              k.sldM.style.cursor = "hand";
            }
            function x() {
              var e = u.pickerInsetColor.split(/\s+/),
                t =
                  e.length < 2
                    ? e[0]
                    : e[1] + " " + e[0] + " " + e[0] + " " + e[1];
              k.btn.style.borderColor = t;
            }
            (k.btn.style.display = u.pickerClosable ? "block" : "none"),
              (k.btn.style.position = "absolute"),
              (k.btn.style.left = u.pickerFace + "px"),
              (k.btn.style.bottom = u.pickerFace + "px"),
              (k.btn.style.padding = "0 15px"),
              (k.btn.style.height = "18px"),
              (k.btn.style.border = u.pickerInset + "px solid"),
              x(),
              (k.btn.style.color = u.pickerButtonColor),
              (k.btn.style.font = "12px sans-serif"),
              (k.btn.style.textAlign = "center");
            try {
              k.btn.style.cursor = "pointer";
            } catch (e) {
              k.btn.style.cursor = "hand";
            }
            switch (
              ((k.btn.onmousedown = function () {
                u.hidePicker();
              }),
              (k.btnS.style.lineHeight = k.btn.style.height),
              d)
            ) {
              case 0:
                var w = "hs.png";
                break;
              case 1:
                w = "hv.png";
            }
            (k.padM.style.backgroundImage =
              "url('" + jscolor.getDir() + "cross.gif')"),
              (k.padM.style.backgroundRepeat = "no-repeat"),
              (k.sldM.style.backgroundImage =
                "url('" + jscolor.getDir() + "arrow.gif')"),
              (k.sldM.style.backgroundRepeat = "no-repeat"),
              (k.pad.style.backgroundImage =
                "url('" + jscolor.getDir() + w + "')"),
              (k.pad.style.backgroundRepeat = "no-repeat"),
              (k.pad.style.backgroundPosition = "0 0"),
              i(),
              n(),
              (jscolor.picker.owner = u),
              document.getElementsByTagName("body")[0].appendChild(k.boxB);
          })(C[t], C[o]);
        }
      }),
      (this.importColor = function () {
        m
          ? this.adjust
            ? !this.required && /^\s*$/.test(m.value)
              ? ((m.value = ""),
                (g.style.backgroundImage = g.jscStyle.backgroundImage),
                (g.style.backgroundColor = g.jscStyle.backgroundColor),
                (g.style.color = g.jscStyle.color),
                this.exportColor(k | v))
              : this.fromString(m.value) || this.exportColor()
            : this.fromString(m.value, k) ||
              ((g.style.backgroundImage = g.jscStyle.backgroundImage),
              (g.style.backgroundColor = g.jscStyle.backgroundColor),
              (g.style.color = g.jscStyle.color),
              this.exportColor(k | v))
          : this.exportColor();
      }),
      (this.exportColor = function (e) {
        if (!(e & k) && m) {
          var t = this.toString();
          this.caps && (t = t.toUpperCase()),
            this.hash && (t = "#" + t),
            (m.value = t);
        }
        e & v ||
          !g ||
          ((g.style.backgroundImage = "none"),
          (g.style.backgroundColor = "#" + this.toString()),
          (g.style.color =
            0.213 * this.rgb[0] + 0.715 * this.rgb[1] + 0.072 * this.rgb[2] <
            0.5
              ? "#FFF"
              : "#000")),
          e & j || !l() || i(),
          e & x || !l() || n();
      }),
      (this.fromHSV = function (e, t, o, s) {
        null !== e && (e = Math.max(0, this.minH, Math.min(6, this.maxH, e))),
          null !== t && (t = Math.max(0, this.minS, Math.min(1, this.maxS, t))),
          null !== o && (o = Math.max(0, this.minV, Math.min(1, this.maxV, o))),
          (this.rgb = r(
            null === e ? this.hsv[0] : (this.hsv[0] = e),
            null === t ? this.hsv[1] : (this.hsv[1] = t),
            null === o ? this.hsv[2] : (this.hsv[2] = o)
          )),
          this.exportColor(s);
      }),
      (this.fromRGB = function (e, t, o, s) {
        null !== e && (e = Math.max(0, Math.min(1, e))),
          null !== t && (t = Math.max(0, Math.min(1, t))),
          null !== o && (o = Math.max(0, Math.min(1, o)));
        var i = (function (e, t, o) {
          var r = Math.min(Math.min(e, t), o),
            s = Math.max(Math.max(e, t), o),
            i = s - r;
          if (0 === i) return [null, 0, s];
          var n =
            e === r
              ? 3 + (o - t) / i
              : t === r
              ? 5 + (e - o) / i
              : 1 + (t - e) / i;
          return [6 === n ? 0 : n, i / s, s];
        })(
          null === e ? this.rgb[0] : e,
          null === t ? this.rgb[1] : t,
          null === o ? this.rgb[2] : o
        );
        null !== i[0] &&
          (this.hsv[0] = Math.max(0, this.minH, Math.min(6, this.maxH, i[0]))),
          0 !== i[2] &&
            (this.hsv[1] =
              null === i[1]
                ? null
                : Math.max(0, this.minS, Math.min(1, this.maxS, i[1]))),
          (this.hsv[2] =
            null === i[2]
              ? null
              : Math.max(0, this.minV, Math.min(1, this.maxV, i[2])));
        var n = r(this.hsv[0], this.hsv[1], this.hsv[2]);
        (this.rgb[0] = n[0]),
          (this.rgb[1] = n[1]),
          (this.rgb[2] = n[2]),
          this.exportColor(s);
      }),
      (this.fromString = function (e, t) {
        var o = e.match(/^\W*([0-9A-F]{3}([0-9A-F]{3})?)\W*$/i);
        return (
          !!o &&
          (6 === o[1].length
            ? this.fromRGB(
                parseInt(o[1].substr(0, 2), 16) / 255,
                parseInt(o[1].substr(2, 2), 16) / 255,
                parseInt(o[1].substr(4, 2), 16) / 255,
                t
              )
            : this.fromRGB(
                parseInt(o[1].charAt(0) + o[1].charAt(0), 16) / 255,
                parseInt(o[1].charAt(1) + o[1].charAt(1), 16) / 255,
                parseInt(o[1].charAt(2) + o[1].charAt(2), 16) / 255,
                t
              ),
          !0)
        );
      }),
      (this.toString = function () {
        return (
          (256 | Math.round(255 * this.rgb[0])).toString(16).substr(1) +
          (256 | Math.round(255 * this.rgb[1])).toString(16).substr(1) +
          (256 | Math.round(255 * this.rgb[2])).toString(16).substr(1)
        );
      });
    var u = this,
      d = "hvs" === this.pickerMode.toLowerCase() ? 1 : 0,
      p = !1,
      m = jscolor.fetchElement(this.valueElement),
      g = jscolor.fetchElement(this.styleElement),
      f = !1,
      b = !1,
      y = {},
      k = 1,
      v = 2,
      j = 4,
      x = 8;
    jscolor.isColorAttrSupported = !1;
    var w = document.createElement("input");
    if (
      (w.setAttribute &&
        (w.setAttribute("type", "color"),
        "color" == w.type.toLowerCase() && (jscolor.isColorAttrSupported = !0)),
      jscolor.addEvent(e, "focus", function () {
        u.pickerOnfocus && u.showPicker();
      }),
      jscolor.addEvent(e, "blur", function () {
        p
          ? (p = !1)
          : window.setTimeout(function () {
              p ||
                (m === e && u.importColor(), u.pickerOnfocus && u.hidePicker()),
                (p = !1);
            }, 0);
      }),
      m)
    ) {
      var C = function () {
        u.fromString(m.value, k), h();
      };
      jscolor.addEvent(m, "keyup", C),
        jscolor.addEvent(m, "input", C),
        jscolor.addEvent(m, "blur", function () {
          m !== e && u.importColor();
        }),
        m.setAttribute("autocomplete", "off");
    }
    switch (
      (g &&
        (g.jscStyle = {
          backgroundImage: g.style.backgroundImage,
          backgroundColor: g.style.backgroundColor,
          color: g.style.color,
        }),
      d)
    ) {
      case 0:
        jscolor.requireImage("hs.png");
        break;
      case 1:
        jscolor.requireImage("hv.png");
    }
    jscolor.requireImage("cross.gif"),
      jscolor.requireImage("arrow.gif"),
      this.importColor();
  },
};
jscolor.install();